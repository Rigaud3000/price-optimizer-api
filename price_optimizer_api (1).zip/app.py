from flask import Flask, request, jsonify
from pricing_engine import get_optimal_price

app = Flask(__name__)

@app.route('/price-suggestion', methods=['GET'])
def price_suggestion():
    location = request.args.get('location')
    date = request.args.get('date')

    if not location or not date:
        return jsonify({"error": "Missing required parameters"}), 400

    price = get_optimal_price(location, date)
    return jsonify({"location": location, "date": date, "suggested_price": price})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=10000)