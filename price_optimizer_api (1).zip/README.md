# Short-Term Rental Price Optimizer API

This API suggests optimal nightly prices for Airbnb and vacation rentals based on:
- Local events
- Day of the week
- Competitor pricing

## Endpoints

### GET /price-suggestion

**Params:**
- location (e.g., Miami)
- date (e.g., 2025-07-04)

**Response:**
```json
{
  "location": "Miami",
  "date": "2025-07-04",
  "suggested_price": 140.5
}
```

## Setup

```bash
pip install -r requirements.txt
python app.py
```