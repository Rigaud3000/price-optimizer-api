import json
from datetime import datetime

def get_optimal_price(location, date_str):
    base_price = 100
    date = datetime.strptime(date_str, "%Y-%m-%d")
    weekday = date.weekday()

    # Weekend pricing
    if weekday in [4, 5]:  # Friday, Saturday
        base_price *= 1.3

    # Event boost
    with open("data/mock_events.json") as f:
        events = json.load(f)
        if location in events and date_str in events[location]:
            base_price *= 1.5

    # Competitor pricing adjustment
    with open("data/mock_competitors.json") as f:
        competitors = json.load(f)
        avg_price = sum(competitors.get(location, [base_price])) / len(competitors.get(location, [base_price]))
        base_price = (base_price + avg_price) / 2

    return round(base_price, 2)